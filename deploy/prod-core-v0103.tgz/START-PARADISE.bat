@echo off
setlocal
title Paradise Lawn Care - Local Test
cd /d "%~dp0"

echo ================================================
echo Paradise Lawn Care - v0.10.3 Local Test
echo ================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed or is not in PATH.
  echo Install the current Node.js LTS version, then run this file again.
  echo https://nodejs.org/
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm is not available in PATH.
  pause
  exit /b 1
)

if not exist "node_modules\pg\package.json" (
  echo First-time setup: installing required packages...
  echo This normally takes less than a minute.
  echo.
  call npm install
  if errorlevel 1 (
    echo.
    echo ERROR: npm install failed.
    pause
    exit /b 1
  )
)

echo Starting Paradise local test server...
echo Operations: http://localhost:4173/app
echo Website:    http://localhost:4173/website
echo.

start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 2; Start-Process 'http://localhost:4173/app'"
call npm start

if errorlevel 1 (
  echo.
  echo ERROR: Paradise stopped unexpectedly.
  pause
)
endlocal
